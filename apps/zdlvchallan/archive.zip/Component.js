sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("com.kgpl.zdlvchallan.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map